export interface ExchangeRate {
  table: string;
  no: string;
}
